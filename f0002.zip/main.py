#!/usr/bin/env python3
refrén = 'Csillárom, haj!'
print('Csizmadialegények')
print('\nCsizmadialegények')
print(refrén)
print('Nyolcan ülnek egy lóra')
print(refrén)
print('Úgy mennek a jó borra')
print(refrén)
# a következő sorban felülírjuk a változó értékét
refrén = 'Sej, ripityom!'
print('Parancsolnak kocsmárosnak;')
print('Mérjen egy decit nyócuknak!')
print(refrén) # itt már Sej, ripityom! lesz
print('Azt se tudják kifizetni.')
print('Az ablakon szekdesnek ki.')
print(refrén)

