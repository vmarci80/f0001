#!/usr/bin/env python3
print('szia')
print("Én egy python-program vagyok")
